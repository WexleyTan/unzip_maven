package com.example.latest_maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LatestMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(LatestMavenApplication.class, args);
	}

}
