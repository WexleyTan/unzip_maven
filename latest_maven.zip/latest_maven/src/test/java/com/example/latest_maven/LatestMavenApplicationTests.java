package com.example.latest_maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LatestMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
